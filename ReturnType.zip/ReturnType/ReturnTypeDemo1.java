package ReturnType;

public class ReturnTypeDemo1 {
	
	static int addition()
	{
		int c=20+30;
		return c;
	}
	
	public static void main(String[] args)
	{
		int a=addition();
		System.out.println("ADDITION IS: "+a);
	}
}
