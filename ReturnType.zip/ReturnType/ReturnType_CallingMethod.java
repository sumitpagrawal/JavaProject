package ReturnType;

public class ReturnType_CallingMethod {
	
	static void addition(int no1, int no2) {
		int c=no1+no2;
		System.out.println("ADDITION IS: "+c);
	}
	
	public static void main(String[] args) {
		addition(10,20);
	}
}
