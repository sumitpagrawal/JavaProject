package ReturnType;

public class ReturnTypeDemo2_Method {
	
	static int addition()
	{
		int c=20+50;
		return c;
	}
	
	public static void main(String[] args)
	{
		System.out.println("ADDITION IS: "+addition());
	}
}
